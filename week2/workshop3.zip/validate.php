<?php

    $request = $_REQUEST;
    // รับค่าที่ส่งมาเก็บไว้ในตัวแปร $request
    print_r($request);
    // print_r เพื่อแสดงข้อมูลในตัวแปร $request
    echo '<br>';
    // วนลูปเพื่อแสดงข้อมูลที่ส่งมาในรูปแบบ Key-Value ด้วย foreach
    foreach( $request as $key => $value ) {
        echo "Key: $key, Value: $value<br>";
    }

?>